# Two-session concurrency test plan (manual)
1. Set a test book's available count to one.
2. Open independent SQLite connections A and B.
3. Begin a write transaction in A and conditionally decrement the stock.
4. While A holds the write lock, attempt the same conditional update in B.
5. Record whether B waits or receives a lock/busy response; configure a bounded busy timeout.
6. Commit A, then retry B in a fresh transaction. B's conditional update must affect zero rows.
7. Verify final stock is zero and only one loan was created.

Expected invariant: two borrowers must never both receive the final copy. This is a manual test plan, not a claimed executed result.
