# Relational design and normalisation
The schema separates members, staff, books, authors, loans and individual loan items. `book_authors` resolves the many-to-many relationship between books and authors; `loan_items` allows a loan to contain multiple books.

- **1NF:** Every field contains a single value; repeating author or book lists are not stored in one column.
- **2NF:** Junction tables use composite keys; their attributes depend on the complete key.
- **3NF:** Member, staff, book and author details are stored in their own tables rather than repeated in each loan.

Primary/foreign keys and constraints protect relationships and data validity. Unique ISBN/email values prevent duplicates; stock checks prevent negative or impossible available-copy counts. Sample emails use the reserved `.test` domain.
