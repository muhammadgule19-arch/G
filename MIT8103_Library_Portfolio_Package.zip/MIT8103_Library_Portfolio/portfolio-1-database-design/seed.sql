INSERT INTO members VALUES (1,'Amina Yusuf','amina@example.test','2026-01-10'),(2,'Daniel Okafor','daniel@example.test','2026-02-05'),(3,'Zainab Bello','zainab@example.test','2026-03-12');
INSERT INTO staff VALUES (1,'Grace Nwosu','grace.staff@example.test','LIBRARIAN'),(2,'Ibrahim Musa','ibrahim.staff@example.test','ADMIN');
INSERT INTO authors VALUES (1,'Chinua Achebe'),(2,'Buchi Emecheta'),(3,'George Orwell'),(4,'Chimamanda Ngozi Adichie');
INSERT INTO books VALUES (1,'9780385474542','Things Fall Apart','Literature',1958,4,2),(2,'9780435906941','The Joys of Motherhood','Literature',1979,3,2),(3,'9780451524935','Animal Farm','Political Fiction',1945,5,4),(4,'9780000000004','Half of a Yellow Sun','Historical Fiction',2006,3,3),(5,'9780000000005','Database Systems','Technology',2020,2,1);
INSERT INTO book_authors VALUES (1,1),(2,2),(3,3),(4,4);
INSERT INTO loans VALUES (1,1,1,'2026-10-01','2026-10-15','OPEN'),(2,2,1,'2026-10-20','2026-11-03','OPEN'),(3,3,2,'2026-09-01','2026-09-15','CLOSED');
INSERT INTO loan_items VALUES (1,5,NULL),(2,3,NULL),(3,1,'2026-09-12');
