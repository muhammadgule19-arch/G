from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]; DB=ROOT/'library.db'
if not DB.exists(): raise SystemExit('Run scripts/build_database.py first')
def issue(con,member,staff,book,loan):
 con.execute('BEGIN')
 cur=con.execute('UPDATE books SET available_copies=available_copies-1 WHERE book_id=? AND available_copies>0',(book,))
 if cur.rowcount!=1: con.rollback(); return False
 con.execute('INSERT INTO loans VALUES(?,?,?,?,?,?)',(loan,member,staff,'2026-10-31','2026-11-14','OPEN'))
 con.execute('INSERT INTO loan_items VALUES(?,?,NULL)',(loan,book)); con.commit(); return True
with sqlite3.connect(DB) as con:
 con.execute('PRAGMA foreign_keys=ON')
 before=con.execute('SELECT available_copies FROM books WHERE book_id=5').fetchone()[0]
 assert issue(con,3,1,5,99); after=con.execute('SELECT available_copies FROM books WHERE book_id=5').fetchone()[0]
 assert after==before-1; print('Commit test: PASS')
 rollback_before=con.execute('SELECT available_copies FROM books WHERE book_id=1').fetchone()[0]
 con.execute('BEGIN'); con.execute('UPDATE books SET available_copies=available_copies-1 WHERE book_id=1'); con.rollback()
 assert con.execute('SELECT available_copies FROM books WHERE book_id=1').fetchone()[0]==rollback_before; print('Rollback test: PASS')
 try:
  con.execute('UPDATE books SET available_copies=-1 WHERE book_id=5'); con.commit(); raise AssertionError('CHECK did not reject negative stock')
 except sqlite3.IntegrityError: con.rollback(); print('CHECK constraint test: PASS')
