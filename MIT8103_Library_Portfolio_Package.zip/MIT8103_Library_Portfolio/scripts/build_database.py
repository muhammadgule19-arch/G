from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'library.db'
if DB.exists(): DB.unlink()
with sqlite3.connect(DB) as con:
    con.execute('PRAGMA foreign_keys=ON')
    con.executescript((ROOT/'portfolio-1-database-design/schema.sql').read_text())
    con.executescript((ROOT/'portfolio-1-database-design/seed.sql').read_text())
    assert not con.execute('PRAGMA foreign_key_check').fetchall()
    for table in ['members','staff','authors','books','book_authors','loans','loan_items']:
        print(f'{table}: {con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]} rows')
print('Database build and foreign-key check: PASS')
