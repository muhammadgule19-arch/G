-- Q1 Active loans with borrower and book details
SELECT l.loan_id,m.full_name,b.title,l.loan_date,l.due_date FROM loans l JOIN members m ON m.member_id=l.member_id JOIN loan_items li ON li.loan_id=l.loan_id JOIN books b ON b.book_id=li.book_id WHERE l.status='OPEN' ORDER BY l.due_date;
-- Q2 Most borrowed books
SELECT b.title,COUNT(*) AS times_borrowed FROM loan_items li JOIN books b ON b.book_id=li.book_id GROUP BY b.book_id,b.title ORDER BY times_borrowed DESC,b.title;
-- Q3 Overdue active loans at fixed assessment date
SELECT l.loan_id,m.full_name,b.title,l.due_date FROM loans l JOIN members m ON m.member_id=l.member_id JOIN loan_items li ON li.loan_id=l.loan_id JOIN books b ON b.book_id=li.book_id WHERE l.status='OPEN' AND l.due_date<'2026-10-31' ORDER BY l.due_date;
-- Q4 Catalogue title search
SELECT book_id,title,category,available_copies FROM books WHERE title LIKE 'Data%' ORDER BY title;
-- Query plan for overdue lookup
EXPLAIN QUERY PLAN SELECT loan_id,member_id,due_date FROM loans WHERE status='OPEN' AND due_date<'2026-10-31';
