# MIT 8103 — Advanced Database Systems Portfolio
**Student:** Muhammad Sammani Sani Gule  
**Session:** 2026/2027 First Semester  
**Case study:** Community Library Management System  
**GitHub:** https://github.com/muhammadgule19-arch/G

## Contents
- `portfolio-1-database-design/`: relational schema, seed data, ERD and normalisation.
- `portfolio-2-query-optimisation/`: four SQL queries and performance discussion.
- `portfolio-3-transactions-concurrency/`: transaction workflow and concurrency notes.
- `portfolio-4-nosql/`: MongoDB document example and mongosh commands.
- `portfolio-5-distributed-cloud/`: proposed distributed/cloud architecture.
- `scripts/`: reproducible SQLite build, query and transaction tests.
- `evidence/`: outputs produced by running the scripts.

## Run locally
Requires Python 3.10+; SQLite is included with Python.
```bash
python scripts/build_database.py
python scripts/run_queries.py
python scripts/test_transactions.py
```

## Evidence boundaries
SQLite build, query analysis, commit/rollback and constraint checks are executable locally. MongoDB commands require a MongoDB server and are not claimed as executed. The distributed/cloud section is a design proposal, not a deployed cluster. Query timings on the small synthetic dataset are illustrative only.

## Academic integrity / AI use
AI assistance was used to help organise the portfolio, draft and review example code and documentation. The student must review, run, understand and correct the material before submission and ensure this declaration accurately reflects the assistance used. Add a personal reflection based on your own experience. Do not claim tests or deployments you did not perform.
