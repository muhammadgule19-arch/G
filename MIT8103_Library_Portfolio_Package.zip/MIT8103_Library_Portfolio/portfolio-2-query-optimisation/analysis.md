# Query and performance analysis
Indexes support the demonstrated access paths: `idx_books_title` for title lookup, `idx_loans_member_status` for a member's open loans, `idx_loans_due_status` for status plus due-date filtering, and `idx_loan_items_book` for reverse book-to-loan lookup.

`scripts/run_queries.py` prints query results, SQLite query-plan details and seven-run timing samples. The dataset is intentionally small; timings are illustrative and cannot establish production performance. A sound benchmark needs representative data volume, warm-up, controlled hardware, repeated runs and the same workload before/after index changes. Indexes also consume storage and add write overhead, so their benefit should be measured.
