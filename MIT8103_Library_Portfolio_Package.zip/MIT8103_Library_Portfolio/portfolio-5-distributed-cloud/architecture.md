# Distributed and cloud database proposal

## Logical architecture
Application/API -> PostgreSQL primary (authoritative writes) -> asynchronous read replica(s) for reporting. Encrypted point-in-time backups are stored in a separate failure domain. A document store may hold flexible activity events but is not authoritative for stock or loan issuance.

## Consistency and availability
Stock and loan decisions go to the primary to avoid stale replica reads. Reporting can use a replica where bounded replication lag is acceptable. Monitor lag; if it exceeds an agreed threshold, route reporting to the primary or delay it. Failover requires health checks, fencing/leader election and a tested promotion procedure to prevent split-brain writes.

## Recovery and security
Proposed starting targets are RPO <= 5 minutes and RTO <= 60 minutes; these are design objectives, not measured guarantees. Use encrypted backups, WAL archiving, restricted restore permissions and scheduled restore drills. Apply TLS, encryption at rest, least-privilege roles, managed secrets, audit logs, patching, monitoring and MFA-protected administrative access.

## Scaling and limitations
Avoid premature sharding. Measure data volume, query load and bottlenecks first; consider partitioning or sharding only when indexing, replicas and vertical scaling are insufficient. This is a design proposal, not a deployed cloud cluster. Provider-specific failover and recovery must be tested before production claims are made.
