from pathlib import Path
import sqlite3,time,statistics
ROOT=Path(__file__).resolve().parents[1]; DB=ROOT/'library.db'
if not DB.exists(): raise SystemExit('Run scripts/build_database.py first')
queries={
'active_loans':"SELECT l.loan_id,m.full_name,b.title,l.due_date FROM loans l JOIN members m ON m.member_id=l.member_id JOIN loan_items li ON li.loan_id=l.loan_id JOIN books b ON b.book_id=li.book_id WHERE l.status='OPEN' ORDER BY l.due_date",
'popular_books':"SELECT b.title,COUNT(*) FROM loan_items li JOIN books b ON b.book_id=li.book_id GROUP BY b.book_id,b.title ORDER BY COUNT(*) DESC",
'overdue':"SELECT l.loan_id,m.full_name,b.title,l.due_date FROM loans l JOIN members m ON m.member_id=l.member_id JOIN loan_items li ON li.loan_id=l.loan_id JOIN books b ON b.book_id=li.book_id WHERE l.status='OPEN' AND l.due_date<'2026-10-31' ORDER BY l.due_date",
'title_search':"SELECT book_id,title FROM books WHERE title LIKE 'Data%' ORDER BY title"}
with sqlite3.connect(DB) as con:
 for name,sql in queries.items():
  rows=con.execute(sql).fetchall(); samples=[]
  for _ in range(7):
   start=time.perf_counter(); con.execute(sql).fetchall(); samples.append((time.perf_counter()-start)*1000)
  print(f'\n{name}: {len(rows)} row(s)'); [print(row) for row in rows]
  print(f'7-run mean: {statistics.mean(samples):.4f} ms')
 print('\nOverdue query plan:')
 for row in con.execute("EXPLAIN QUERY PLAN SELECT loan_id,member_id,due_date FROM loans WHERE status='OPEN' AND due_date<'2026-10-31'"): print(row)
