use library_portfolio;
db.loans.insertOne({_id:"loan-1001",member:{member_id:1,name:"Amina Yusuf"},loan_date:ISODate("2026-10-01T10:15:00Z"),due_date:ISODate("2026-10-15T00:00:00Z"),status:"OPEN",items:[{book_id:5,title:"Database Systems",returned_on:null}],events:[{type:"ISSUED",at:ISODate("2026-10-01T10:15:00Z"),staff_id:1},{type:"REMINDER_SENT",at:ISODate("2026-10-10T08:00:00Z"),channel:"email"}]});
db.loans.createIndex({"member.member_id":1,status:1});
db.loans.createIndex({due_date:1,status:1});
db.loans.find({status:"OPEN",due_date:{$lt:ISODate("2026-10-31T00:00:00Z")}});
db.loans.aggregate([{$unwind:"$items"},{$group:{_id:"$items.book_id",title:{$first:"$items.title"},loanCount:{$sum:1}}},{$sort:{loanCount:-1}}]);
